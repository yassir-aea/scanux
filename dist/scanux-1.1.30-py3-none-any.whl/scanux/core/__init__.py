"""
Core functionality for scanux
""" 