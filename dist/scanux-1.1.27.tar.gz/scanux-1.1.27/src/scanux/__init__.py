"""
Scanux - System security and performance scanner
"""

__version__ = "1.0.0" 